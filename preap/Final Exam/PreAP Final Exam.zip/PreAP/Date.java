public class Date
{
   // Instance Variables
   private int Month;
   private int Day;
   private int Year;
   
   // Default Constructor
   public Date()
   {
      Day = 0;
      Month = 0;
      Year = 0;
   }   
   // Second Constructor
   public Date(int m, int d, int y)
   {
      Day = d;
      Month = m;
      Year = y;
   }
   
   // Accessor Methods
   public int getDay()
   {
      return Day;
   }
   
   public int getMonth()
   {
      return Month;
   }
   
   public int getYear()
   {
      return Year;
   }
   
   // Mutator Methods
   public void setDay(int d)
   {
      Day = d;
   }
   
   public void setMonth(int m)
   {
      Month = m;
   }
   
   public void setYear(int y)
   {
      Year = y;
   }
   
   // toString Method
   public String toString()
   {
      String str;
      str = Month + "/" + Day + "/" + Year;
      return str;
   }
}
