import java.util.*;

public class Problem5
{
	public static void main(String[] args)
	{
		// Do not modify this method
		Problem5 test = new Problem5();

		Date date1 = new Date(5,26,2014);

		test.SlashFormat(date1);
		test.DashFormat(date1);
		test.WordFormat(date1);
		System.out.println();

		Date date2 = new Date(9,11,2015);

		test.SlashFormat(date2);
		test.DashFormat(date2);
		test.WordFormat(date2);
		System.out.println();

	}
	public void SlashFormat(Date date)
	{
	   // Prints a Date object in Slash Format (month/day/year)


	}

	public void DashFormat(Date date)
	{
	   // Prints a Date object in Dash format (month-day-year)


	}

	public void WordFormat(Date date)
	{
	   // Converts a Date objects month field into word format then
	   // prints the date object (month day, year)


	}
}