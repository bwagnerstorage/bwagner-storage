import java.util.*;

public class Problem1
{
	public static void main(String[] args)
	{
		System.out.println("***********");
		System.out.println(" Problem 1");
		System.out.println("***********");
		
		Scanner keyboard = new Scanner(System.in);
		
		// - Write solution below this line - //



	}
}