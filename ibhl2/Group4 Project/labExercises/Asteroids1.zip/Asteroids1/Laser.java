import greenfoot.*;

public class Laser extends Actor
{
    public Laser()
    {
        // Creates an image a draws a white laser on the imaged
        GreenfootImage image = new GreenfootImage(4,2);  // create a blank image size (4 by 2)
        image.setColor(Color.WHITE);
        
        image.fillRect(0,0,4,2);   // draw laser
        setImage(image);           // sets laser as object's image
    }
    
    public void act() 
    {
       move(5);   // laser speed = 5 pixels
        
       boolean dead = testBoundary(); // if dead = true, laser needs to be removed from world
       
       if(dead == true)
       {
           getWorld().removeObject(this);  // remove this laser
       }
        
    }   
    
    // This method removes this laser from the world when if goes off screen
    public boolean testBoundary()
    {
        // laser moves out of sight horizontally remove from world
        if(getX() < -4 || getX() > getWorld().getWidth() + 4)
        {
            return true;
        }
        
        // laser moves out of sight horizontally remove from world
        if(getY() < -2 || getY() > getWorld().getHeight() + 2)
        {
            return true;
        }
        
        return false;
    }
    
}
