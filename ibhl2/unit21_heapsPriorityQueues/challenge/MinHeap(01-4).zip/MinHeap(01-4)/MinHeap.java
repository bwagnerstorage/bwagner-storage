public class MinHeap
{
    private TreeNode root;
    
    public MinHeap()
    {
        root = null;
    }
    
    public void setRoot(TreeNode node)
    {
        root = node;
    }

    // part (a)
    public TreeNode smallerChild(TreeNode T)
    {



    }
    
    
    // part (b)
    public boolean isHeapOrdered(TreeNode T)
    {



    }
    
    // part (c)
    // precondition: T is not null
	private TreeNode removeMinHelper(TreeNode T)
	{



	}
	
	public Object removeMin()
	{
	   if(root == null)
	      return null;
	   else
	   {
	      Object result = root.getValue();
		  root = removeMinHelper(root);
		  return result;
	   }
	}
    
    
   /***********************************/
   /*            toString             */
   /***********************************/ 
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }  
   
   private String toString(TreeNode tree, int level)
   {
      String str = "";
      if(tree != null)
      {
        str += toString(tree.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += tree.getValue() + "\n";
        str += toString(tree.getLeft(), level + 1);
      }
      
      return str;
   }

}