public class Tester
{
	public static void main(String[] args)
	{
		HeapPriorityQueue queue = new HeapPriorityQueue();
		
		queue.add("Sarah", 5);
		queue.add("Bill", 3);
		queue.add("Jamie", 4);
		queue.add("Mark", 3);
		queue.add("Kendall", 2);
		queue.add("Tami", 1);
		
		System.out.println();
		System.out.println("Test peek");
		System.out.println("---------");
		System.out.println(queue.peek());
		System.out.println();
		
		System.out.println();
		System.out.println("Test remove");
		System.out.println("-----------");
		while(!queue.isEmpty())
		{
		   System.out.println(queue.remove());
		}
		System.out.println();
	}
}