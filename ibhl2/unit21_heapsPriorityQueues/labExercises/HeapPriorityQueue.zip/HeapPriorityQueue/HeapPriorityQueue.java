public class HeapPriorityQueue implements Queue
{


}

