public class MaxHeap
{
    public final int CAPACITY = 50;
    private int[] heap;
    private int size;
    
    public MaxHeap()
    {
        heap = new int[CAPACITY];
        size = 0;
    }
    
    // adds an item to the heap
    // it first adds the item to the end of the heap then
    // calls the method reheapUpward to place the new item
    // at its correct position in the heap
    // maintaining the maxheap property
    public void insert(int item)
    {
       heap[size] = item;
       reheapUpward();
       size++; 
    }
    
    /*******************************
     *  parent = (i-1) / 2         *
     *  left   = i-1               *
     *  right  = i+1               *
     *  left child = i*2 + 1       *
     *  right child = i*2 + 2      *
     *******************************/
    // part (a)
    // moves the newly added item to its correct location in the heap
    // it advances the new item up the tree by swapping it with its
    // parent until an acceptable location has be found
    private void reheapUpward()
    {



    }
    
    // removes the largest item from the heap then
    // transfers the last item to the newly vacated
    // root position and calls the method reheapDownward
    // to re-establish the maxheap property
    public int removeMax()
    {
        int max = heap[0];
        heap[0] = heap[size-1];
        reheapDownward();
        size--;
                   
        return max;
    }
    
    // part (b)
    // moves the new root to its correct location in the heap
    // it advances the new root down the tree by swapping it with its
    // largest child until an acceptable location has be found
    private void reheapDownward()
    {



    }
    
    public int size()
    {
        return size;
    }
    
    public String toString()
    {
        String str="";
        
        for(int i=0; i < size; i++)
          str += heap[i] + " ";
          
        return str;
    }
}