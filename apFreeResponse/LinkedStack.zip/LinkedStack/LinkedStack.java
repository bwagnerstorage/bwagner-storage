public class LinkedStack<E> implements Stack<E>
{
	// instance variables
	private ListNode top;

	public LinkedStack()
	{
		top = null;
	}

    public void push(E item)
    {

    }

    public E pop()
    {

    }

    public E peek()
    {

    }

    public boolean isEmpty()
    {

    }

    public String toString()
    {

    }
}