import info.gridworld.grid.*;
import info.gridworld.actor.*;

import java.util.*;

public class AttractiveCritter extends Critter
{

}