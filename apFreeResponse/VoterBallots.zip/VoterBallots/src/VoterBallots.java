import java.util.*;

public class VoterBallots
{
	private Map<String, Integer> voteCount;
	
	// part (a)
	// precondition: each entry in ballotList is a Set representing
    //     one voter's ballot
    // postcondition: voteCount.get(candidate) is the total number of
    //     times candidate appears on ballots in ballotList
    public VoterBallots(List<Set> ballotList)
	{


	}
	
	// part (b)
	// postcondition: returns a set containing the candidate(s)
    //    with the most votes
    public Set<String> candidatesWithMost()
    {


    }
    
    // postcondition: returns an Integer object with value equal to the
    //    maximum number of votes associated with any
    //    key in the Map voteCount
    private int maxVotes()
    {
    	Set<String> keys = voteCount.keySet();
    	Iterator iter = keys.iterator();
    	int largest = 0;
    	while(iter.hasNext())
    	{
    	   int num = voteCount.get(iter.next());
    	   if(num > largest)
    	      largest = num;	
    	}
    	return largest;
    }
    
    // part(c) 
    //   Assume that there are C candidates and V voters.
    //   What is the expected time complexity, in Big-Oh
    //   notation in terms of C and V, for your implementation
    //   of method candidatesWithMost ? 
    //
    
    
    
    
    
    
    
    public void printSet(Set<String> set)
    {
       Iterator<String> iter = set.iterator();
       if(iter.hasNext())
          System.out.print("{");
       while(iter.hasNext())
       {
       	  String str = iter.next();
       	  if(iter.hasNext())
       	     System.out.print(str + ",");
       	  else
       	     System.out.println(str + "}");
       }	
       System.out.println();
    }
    
    public void printMap()
    {
       Set<String> keys = voteCount.keySet();
       Iterator<String> iter = keys.iterator();	
       while(iter.hasNext())
       {
       	  String str = iter.next();
       	  System.out.print(str + " - ");
       	  int votes = voteCount.get(str);
       	  System.out.println(votes);
       }
       System.out.println();
    }
    
    public static void main(String[] args)
    {
    	List<Set> ballotList = new LinkedList<Set>();
    	Set<String> set1 = new HashSet<String>();
    	set1.add("Chris");
    	set1.add("Jamie");
    	Set<String> set2 = new HashSet<String>();
    	set2.add("Chris");
    	set2.add("Sandy");
    	Set<String> set3 = new HashSet<String>();
    	set3.add("Chris");
    	set3.add("Sandy");
    	set3.add("Pat");
    	set3.add("Jamie");
    	Set<String> set4 = new HashSet<String>();
    	set4.add("Pat");
    	Set<String> set5 = new HashSet<String>();
    	set5.add("Sandy");
    	set5.add("Jamie");
    	Set<String> set6 = new HashSet<String>();
    	set6.add("Sandy");
    	set6.add("Pat");
    	set6.add("Jamie");
    	Set<String> set7 = new HashSet<String>();
    	set7.add("Jamie");
    	set7.add("Chris");
    	
    	ballotList.add(set1);
    	ballotList.add(set2);
    	ballotList.add(set3);
    	ballotList.add(set4);
    	ballotList.add(set5);
    	ballotList.add(set6);
    	ballotList.add(set7);
    	
    	VoterBallots app = new VoterBallots(ballotList);
    	
    	System.out.println("Voting");
    	System.out.println("------");
    	Iterator<Set> iter = ballotList.iterator();
    	while(iter.hasNext())
    	{
    		app.printSet(iter.next());
    	}
    	System.out.println("Vote Tally");
    	System.out.println("----------");
    	app.printMap();
    	System.out.println("Most Votes");
    	System.out.println("----------");
    	app.printSet(app.candidatesWithMost());
    }
}