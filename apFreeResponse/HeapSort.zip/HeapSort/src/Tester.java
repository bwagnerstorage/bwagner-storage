public class Tester
{
	public static void main(String[] args)
	{
		int[] a = {40, 95, 34, 20, 5, 64, 22, 81, 19, 75};
		
		System.out.println("Heap Sort");
		System.out.println();
		System.out.println("Before sort");
		System.out.println("-----------");
		for(int n : a)
		{
			System.out.print(n + " ");
		}
		System.out.println(); System.out.println();
		
		HeapSort.sort(a);
		
		System.out.println("After sort");
		System.out.println("----------");
		for(int n : a)
		{
			System.out.print(n + " ");
		}
		System.out.println(); System.out.println();
	}
}