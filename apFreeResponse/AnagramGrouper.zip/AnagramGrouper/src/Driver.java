import java.util.*;

public class Driver
{
	public static void main(String[] args)
	{
		
		ArrayList <String> list = new ArrayList<String>();
		list.add("poodle");
		list.add("looped");
		list.add("polled");
		list.add("ant");
		list.add("tan");
		list.add("introduces");
		list.add("reductions");
		list.add("discounter");
		list.add("retains");
		list.add("retinas");
		list.add("nastier"); 
		
		AnagramGrouper group = new AnagramGrouper(list);
		
		group.printMap();
		
		// findLargestSets Test
		System.out.println();
		System.out.println("findLargestSets Test");
		System.out.println("--------------------");
		
		HashSet<HashSet<String>> set = group.findLargestSets();
		
		printSet(set);
		System.out.println();
	    System.out.println();
		
	}

	public static void printSet(HashSet<HashSet<String>> set)
	{
		for(HashSet<String> s : set)
		{
		    System.out.print("{");
		    int i=0;
		    
		    for(String word : s)
		    {
		    	if(i < s.size()-1)
		    		System.out.print(word + ", ");
		    	else
		    		System.out.print(word);
		    	i++;
		    			
		    }
		    System.out.println("}");	
		}

	}
}