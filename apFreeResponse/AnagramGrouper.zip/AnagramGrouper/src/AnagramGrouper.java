import java.util.*;

public class AnagramGrouper
{
    // Maps a key string to a corresponding anagram set
    private HashMap<String, HashSet<String>> groups;
    
    // part (a)
    /** Constructs a map from words in which the keys are key strings and the
     *  value associated with a key string is the set of anagrams having that key string.
     *  Postcondition: each entry of words is contained in an anagram set
     *  @param words a list of strings to be grouped into anagram sets
     *         Precondition: words.size() > 0
     */
    public AnagramGrouper(List<String> words)
    { 




    }
    
    // part (b)
    /** @return a set of all anagram sets of largest size in this AnagramGrouper
     */
    public HashSet<HashSet<String>> findLargestSets()
    {



    	
    }
    
    /** @param s a word
     *  @return a string with the same letters as s, arranged in alphabetical order
     */
    private String createKeyString(String s)
    { 
          StringBuffer buffer = new StringBuffer(s);
		  int i, j;
		  int min;
		  String temp;
		
		  for (i = 0; i < buffer.length()-1; i++)
		  {
		    min = i;
		    for (j = i+1; j < buffer.length(); j++)
		    {
		      if (buffer.charAt(j) < buffer.charAt(min))
		        min = j;
		    }
		    // swap
		    temp = buffer.substring(i, i+1);
		    buffer.replace(i,i+1, buffer.substring(min, min+1));
		    buffer.replace(min, min+1, temp);
		  } 
		  
		  
		return new String(buffer);
    
    }
    
    public void printMap()
    {
    	Set <String> keys = groups.keySet();
    	for(String key : keys)
    	{
    		HashSet<String> set = groups.get(key);
    		System.out.print(key + " - ");
    		System.out.print("{");
    		int i=0;
    		
    		for(String word : set)
    		{
    			if(i < set.size()-1)
    			   System.out.print(word + ", ");
    			else
    			   System.out.print(word);
    			i++;
    			
    		}
    		System.out.println("}");
    	}
    	System.out.println();
    }
    
    
    // There may be instance variables, constructors, and methods that are not shown.
}
