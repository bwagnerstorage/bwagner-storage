import java.util.*;
import java.io.*; 

public class UnitedStates
{
	// instance variables
	private ArrayList <State> states;
	
	public UnitedStates()
	{
	   states = new ArrayList <State> ();
	   
	   readFile();
	   printStates();
	   mergeSort(states, 0, states.size()-1);
	   System.out.println();
	   System.out.println("=========================");
	   System.out.println("  Sorted by Population");
	   System.out.println("=========================");
	   printStates();	
	}
	
	// Sorts an array list using the merge sort algorithm
	void mergeSort(ArrayList <State> list, int lo, int hi)
	{
	   if (lo < hi)
	   {
	       int m = (lo + hi) / 2;
	       mergeSort (list, lo, m);
	       mergeSort (list, m+1, hi);
	       merge (list, lo, hi);
	   }
	}

    // Merge method called by mergeSort
	void merge(ArrayList <State> list, int lo, int hi)
	{





	}
	
	public void printStates()
	{
		for(State s : states)
		{
			System.out.printf("%-15s", s.getName());
			System.out.printf("%-15s", s.getCapital());
			System.out.printf("%-25s", s.getNickname());
			System.out.printf("%10s\n", s.getPopulation());	
		}
	}
	
	public void readFile()
	{
		Scanner scan = null;
		try
		{
			scan = new Scanner(new File("states.txt"));
		}
		catch(FileNotFoundException ex)
		{
			System.out.println("File not Found!");
		}
		
		String name;
		String capital;
		String nickname;
		int population;
		while(scan.hasNextLine())
		{
			name = scan.nextLine();
			capital = scan.nextLine();
			nickname = scan.nextLine();
			population = scan.nextInt();
			if(scan.hasNextLine())
			{
			   String dummy = scan.nextLine();	
			}
			  
			
			State state = new State(name, capital, nickname, population);
			states.add(state);
		}
		
		
		
	}
}