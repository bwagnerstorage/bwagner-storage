function yahtzee() {
    this.context = null;  // reference to canvas context
    this.dice = [];       // array representing 5 dice
    this.images = [];     // array to store 6 die images
    this.loadCount = 0;   // count of number of images loaded
    this.rolled = false;  // flag to test if a dice roll is in progress
    this.numRolls = 3;
};

yahtzee.prototype.initialize = function() {
    this.context = document.getElementById("myCanvas").getContext("2d");
    this.loadImages();
};

yahtzee.prototype.loadImages = function() {
    for(var i=0; i < 6; i++)
    {
        var img = new Image();
        (function(that, image, j) {
        image.onload = function() {
            that.images[j] = image;
            that.loadCount++;
            if(that.loadCount === 6)
                that.buildDice();
        };
    })(this, img, i);  // closure
    var filename = "images/d"+ (i+1) + ".png";
    img.src = filename;  
    }   
};

yahtzee.prototype.buildDice = function() {
    for(var i = 0; i < 5; i++)
    {
        this.dice[i] = {value : i, hold : false};
    }
};

yahtzee.prototype.draw = function() {
    var x = 0;
    for(var i = 0; i < this.dice.length; i++)
    { 
        var img = this.images[this.dice[i].value - 1];
        this.context.drawImage(img, x, 10, 108, 108);
        x+=120;
    } 
};

yahtzee.prototype.rollDice = function()
{     
    var that = this;  // store current this object
    if(!that.rolled) {
        
        var current = new Date();  // current time in millis
        var rollTime = current.getTime() + 2000;  // current time + 2 seconds
        
        that.rolled = true;  // started roll sequence

            // spin dice images every 1/10 of a second for 2 seconds
            var timer = setInterval(function(){ spinDice(); }, 100); 
            
            // inner function
            function spinDice() {
                for(var i = 0; i < 5; i++)
                {
                    if(that.dice[i].hold === false)
                    {
                        var index = Math.floor(Math.random() * 6) + 1;
                        that.dice[i].value = index;
                    }
                }

            that.draw();  // draw dice

            if(new Date().getTime() > rollTime)  // can't roll while rolling
            {
                that.rolled = false;
                clearInterval(timer);  // stop spinning after 2 seconds
                
                that.endTurn(that);
            }
        }
        
        
        
    }
    
};

// param obj - is a reference to the yahtzee object
yahtzee.prototype.endTurn = function(obj)
{
 
 
};

yahtzee.prototype.resetTurn = function()
{


};

yahtzee.prototype.disableButtons = function()
{
    document.getElementById("rollButton").disabled = true;
    for(var i = 0; i < 5; i++)
    {
        var die = document.getElementById("hold" +(i));
        die.disabled = true;
    }
};

yahtzee.prototype.enableButtons = function()
{
    document.getElementById("rollButton").disabled = false;
    for(var i = 0; i < 5; i++)
    {
        var die = document.getElementById("hold" +(i));
        die.disabled = false;
    }
};

yahtzee.prototype.hideDice = function()
{
    this.context.clearRect(0,0,590,120); 
};

yahtzee.prototype.holdDice = function(dieNumber)
{
    var die = document.getElementById("hold" + dieNumber);
    
    if(this.dice[dieNumber].hold === false)
    {
        this.dice[dieNumber].hold = true;
        die.style.backgroundColor = "gold";
    }
    else
    {
        this.dice[dieNumber].hold = false;
        die.style.backgroundColor = "lightgoldenrodyellow";
    }
};





