public class BuildList
{
    // Build1 and Build2 variables
    private ListNode node1;
    private ListNode node2;
    private ListNode node3;
    private ListNode node4;
    private ListNode node5;

    // Build3 variables
    private ListNode head;
    private ListNode cur;
    private ListNode newNode;

    public BuildList()
    {
        build1();
        printList(node1);

        build2();
        printList(node1);

        build3();
        printList(head);
        
        build4();
        printList(head);
        
        build5();
        printList(head);
    }

    public void build1()
    {
        node5 = new ListNode(5, null);    // create node5 with no link to another node
        node4 = new ListNode(4, node5);   // create node4 and link it to node5
        // Create node3 and link it to node 4 (below this line)
        
        // Create node2 and link it to node 3 (below this line)
        
        // Create node1 and link it to node 2 (below this line)

    }

    public void build2()
    {
        node1 = new ListNode(1, null);   // create node1
        node2 = new ListNode(2, null);   // create node2
        // Create nodes 3,4,5 and set next varialbe to null (below this line)
        
        
        node1.setNext(node2); // link node1 to node2
        // Use setNext to link nodes 2 to 3, 3 to 4, 4 to 5 (below this line)

        
    }

    public void build3()
    {

    }
    
    public void build4()
    {

    }
    
    public void build5()
    {

    }

    public void printList(ListNode head)
    {
        ListNode cur = head;
        while(cur != null)
        {
            System.out.print(cur.getValue() + " ");
            cur = cur.getNext();
        }
        System.out.println();
    }

    public static void main(String[] args)
    {
        BuildList app = new BuildList();
    }
}