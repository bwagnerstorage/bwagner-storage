
public class FrogSimulationDriver 
{
    public static void main(String[] args)
    {
        FrogSimulation sim1 = new FrogSimulation(12, 9);    // 12 goal, 9 hops
        FrogSimulation sim2 = new FrogSimulation(10, 2);    // 10 goal, 2 hops
        FrogSimulation sim3 = new FrogSimulation(20, 6);    // 20 goal,6 hops
        FrogSimulation sim4 = new FrogSimulation(30, 12);    // 30 goal, 12 hops
        
        System.out.println("new FrogSimulation(12, 9)");
        System.out.printf("Proportion: %4s", sim1.runSimulations(50));  // 50 simulations
        System.out.println("   This proportion should trend in the high range.");
        System.out.println();
        System.out.println();
        System.out.println("new FrogSimulation(10, 2)");
        System.out.printf("Proportion: %4s", sim2.runSimulations(50));  // 50 simulations
        System.out.println("   This proportion should trend in the low range.");
        System.out.println();
        System.out.println();
        System.out.println("new FrogSimulation(20, 6)");
        System.out.printf("Proportion: %4s", sim3.runSimulations(50));  // 50 simulations
        System.out.println("   This proportion should trend in the lower middle range.");
        System.out.println();
        System.out.println();
        System.out.println("new FrogSimulation(30, 12)");
        System.out.printf("Proportion: %4s", sim4.runSimulations(50));  // 50 simulations
        System.out.println("   This proportion should trend in the higher middle range.");
        System.out.println();
    }
}
