import java.util.*;

public class WordPairList 
{
    /** The list of word pairs, initialized by the constructor. */
    private ArrayList<WordPair> allPairs;
    
    // Part (a)
    /** Constructs a WordPairList object as described in part(a).
     *  Precondition:words.length >= 2
     */
    
    public WordPairList(String[] words)
    {

    }
    
    // Part (b)
    /** Returns the number of matches as described in part(b).
     */
    public int numMatches()
    {

    }
    
    
    
    
    
    public void print()
    {
        for(int i = 0; i < allPairs.size(); i++)
        {
            WordPair pair = allPairs.get(i);
            if(i % 3 == 0)
                System.out.println();
            System.out.print("(" + pair.getFirst() + ", " + pair.getSecond() + ") ");  
        }
        System.out.println();
    }
}
