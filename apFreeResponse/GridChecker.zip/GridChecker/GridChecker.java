import java.util.*;
import info.gridworld.actor.*;
import info.gridworld.grid.*;

public class GridChecker
{
	/** The grid to check; guaranteed never to be null */
	private BoundedGrid<Actor> gr;
	
	public GridChecker(Grid<Actor> g)
	{
		gr = (BoundedGrid)g;
	}
	
	
	// Part (a)
	/** @return an Actor in the grid gr with the most neighbors; 
	 *   null if no actors in the grid.
	*/
	public Actor actorWithMostNeighbors()
	{ 


	
    }
	
	// Part (b)
	/** Returns a list of all occupied locations in the grid gr that are within 2 rows
	* and 2 columns of loc. The object references in the returned list may appear in any order.
	* @param loc a valid location in the grid gr
	* @return a list of all occupied locations in the grid gr that are within 2 rows
	* and 2 columns of loc.
	*/
	public List<Location> getOccupiedWithinTwo(Location loc)
	{


		
    }
	
	
	// There may be instance variables, constructors, and methods that are not shown.
}