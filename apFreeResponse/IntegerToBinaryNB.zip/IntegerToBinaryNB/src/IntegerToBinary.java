import java.util.*;

public class IntegerToBinary
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("********************************");
        System.out.println("   Integer to Binary Converter");
        System.out.println("********************************");
        System.out.println();
        System.out.print("Enter an integer-->");
        int num = keyboard.nextInt();
        
        String ans = convert(num);
        
        System.out.println("Binary number = " + ans);
        System.out.println("\n");
    }
    
    // This method converts an integer value into binary.
    // The returned binary number is represented as a string of zeros and ones.
    public static String convert(int num)
    {
        
        return "";
    }
}