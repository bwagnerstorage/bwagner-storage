public class JohnWayne implements Employee 
{ 
   public int getAge()
   {
   	  return 70;
   }
   public int getYearsOnJob()
   {
   	  return 35;
   } 
   public double getSalary()
   {
   	  return 100000;
   }
   public int getID()
   {
   	  return 100;
   }
} 