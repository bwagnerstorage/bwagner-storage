public class HenryFonda implements Employee 
{ 
   public int getAge()
   {
   	  return 75;
   }
   public int getYearsOnJob()
   {
   	  return 20;
   } 
   public double getSalary()
   {
   	  return 200000;
   }
   public int getID()
   {
   	  return 500;
   }
}