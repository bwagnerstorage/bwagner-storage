public interface Employee 
{ 
   int getAge(); 
   int getYearsOnJob(); 
   double getSalary(); 
   int getID(); 
} 