public class MarilynMonroe implements Employee 
{ 
   public int getAge()
   {
   	  return 62;
   }
   public int getYearsOnJob()
   {
   	  return 25;
   } 
   public double getSalary()
   {
   	  return 50000;
   }
   public int getID()
   {
   	  return 300;
   }
}