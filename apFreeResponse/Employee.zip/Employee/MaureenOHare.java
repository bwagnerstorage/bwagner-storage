public class MaureenOHare implements Employee 
{ 
   public int getAge()
   {
   	  return 66;
   }
   public int getYearsOnJob()
   {
   	  return 27;
   } 
   public double getSalary()
   {
   	  return 52000;
   }
   public int getID()
   {
   	  return 600;
   }
}