class Money
{
    // instance variable
    private String money;
    
    // constructor
    public Money(String m)
    {
        money = m;
    }
    
    // postcondition: returns the position of the first dot character
    //                in money or -1 if there is no dot in money
    private int findDot()
    {
       
        
       
            
    }
    // precondition: money corresponds to a decimal number;
    //   i.e., it contains one of the following:
    //   (1) one or more digits
    //   (2) a dot followed by one or more digits, or
    //   (3) one or more digits followed by a dot,
    //       followed by zero or more digits
    public void printMoney()
    {

        
        
        
    }
}