function yahtzee() {
    this.context = null;  // reference to canvas context
    this.dice = [];       // array representing 5 dice
    this.images = [];     // array to store 6 die images
    this.loadCount = 0;   // count of number of images loaded
    this.rolled = false;  // flag to test if a dice roll is in progress
};

yahtzee.prototype.initialize = function() {
    this.context = document.getElementById("myCanvas").getContext("2d");
    this.loadImages();
};

yahtzee.prototype.loadImages = function() {
    for(var i=0; i < 6; i++)
    {
        var img = new Image();
        (function(that, image, j) {
        image.onload = function()     // called when an image is loaded
        {
            that.images[j] = image;
            that.loadCount++;
            if(that.loadCount === 6)   // all images loaded
                that.buildDice();      // start game
        };
    })(this, img, i);  // closure
    var filename = "images/d"+ (i+1) + ".png";
    img.src = filename;  
    }   
};

yahtzee.prototype.buildDice = function() {
    for(var i = 0; i < 5; i++)
    {
        this.dice[i] = {value : i, hold : false};
    }
};

yahtzee.prototype.draw = function() {
    var x = 0;
    for(var i = 0; i < this.dice.length; i++)
    { 
        var img = this.images[this.dice[i].value];
        this.context.drawImage(img, x, 10, 108, 108);
        x+=120;
    } 
};

yahtzee.prototype.rollDice = function() {   
    if(!this.rolled) {
        var that = this;  // store current this object
        var current = new Date();  // current time in milliseconds
        var rollTime = current.getTime() + 2000;  // current time + 2 seconds
        
        that.rolled = true;  // started roll sequence

        // spin dice images every 1/10 of a second
        var timer = setInterval(function(){ spinDice(); }, 100); 

        // inner function
        function spinDice() {
            // create random value for each die
            for(var i = 0; i < 5; i++)
            {
                var index = Math.floor(Math.random() * 6); // (1 - 6)
                that.dice[i].value = index;
            }

            that.draw();  // draw dice

            if(new Date().getTime() > rollTime)  //  Is time up?
            {
                that.rolled = false;   // prevent two rolls from occurring at same time
                clearInterval(timer);  // stop animation
            }
        }
    }
    
};

yahtzee.prototype.holdDice = function(dieNumber) {



};





