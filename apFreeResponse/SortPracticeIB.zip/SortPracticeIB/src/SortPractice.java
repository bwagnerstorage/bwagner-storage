import java.util.*;

public class SortPractice
{ 
    public static void selectionSort(String[] names)
    {   
        for(int i = 0; i < names.length - 1; i++)
        {
            int min = i;
            // find smallest
            
            for(int j = i+1; j < names.length; j++)
            {
               if(names[j].compareTo(names[min]) < 0)
               {
                   min = j;
               }
            }
            
            // swap values
            String temp = names[i];
            names[i] = names[min];
            names[min] = temp;
        }
    }
    
    public static void bubbleSort(Integer[] nums)
    {
        int i;
        int temp;
        boolean done;
        do
        {
           done = true;

           for(i = 0; i < nums.length-1; i++)
           {
               if (nums[i].compareTo(nums[i + 1]) > 0)
               {            
                   // swap
                   temp = nums[i];
                   nums[i] = nums[i+1];
                   nums[i+1] = temp;
                   done = false;             // made a swap
               }            
           }   
        } 
        while (!done);
    }

    public static void main(String[] args) 
    {
        String[] names = {"Garth", "Cher", "Pink", "Madonna", "Rihana", "Prince", "Adele"};
		
        selectionSort(names);

        bubbleSort(numbers);     
        
    }
}