public class LightBoard
{
    /** The lights on the board, where true represents on and false represents off.
    */
    private boolean[][] lights;
    
    /* Constructors a LightBoard object with specified values. 
    *  Used for testing.
    */
    public LightBoard()
    {
        lights = new boolean[][]{
            {true, true, false, true, true},
            {true, false, false, true, false},
            {true, false, false, true, true},
            {true, false, false, false, true},
            {true, false, false, false, true},
            {true, true, false, true, true},
            {false, false, false, false, false}
        };
    }  
    
    //-------------------------------- Part A -------------------------------//
    /** Constructs a LightBoard object having numRows rows and numCols columns.
    * Precondition: numRows > 0, numCols > 0
    * Postcondition: each light has a 40% probability of being set to on.
    */
    public LightBoard(int numRows, int numCols)
    {

        
    }
    
    
    //-------------------------------- Part B -------------------------------//
    /** Evaluates a light in row index row and column index col and returns a status
    * as described in part (b).
    * Precondition: row and col are valid indexes in lights.
    */
    public boolean evaluateLight(int row, int col)
    { 
 
        
    }
    
    
    
    //--------------------------------------------------------------------------
    public void printBoard()
    {
        for(boolean[] rows : lights)
        {
            for(boolean col : rows)
            {
                System.out.printf("%-7b", col);
            }
            System.out.println("\n");
        }
    } 
}