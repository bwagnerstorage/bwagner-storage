public class Kalamazoo implements College
{
   // instance variables
   private int tuition;
   
   // constructor
   public Kalamazoo(int t)
   {
   	  tuition = t;
   }
   public String getName()
   {
   	  return "Kalamazoo College";
   } 
   public String getRegion()
   {
   	  return "Midwest";
   }
   public int getTuition()
   {
   	 return tuition;
   } 
   public void setTuition(int newTuition)
   {
   	  tuition = newTuition;
   }
}