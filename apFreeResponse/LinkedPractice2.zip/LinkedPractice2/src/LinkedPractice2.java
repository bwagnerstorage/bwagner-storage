import java.util.*;

public class LinkedPractice2
{       
    // removes the first node in the linked list referenced by head
    // returns head
    public static ListNode removeFirstNode(ListNode head)
    {
        return head;
    }
    
    // removes the last node in the linked list referenced by head
    // returns head
    public static ListNode removeLastNode(ListNode head)
    {
        return head;
    }
    
    // adds a new ListNode object with a value of num at the beginning of 
    // the linked list referenced by head; returns head
    public static ListNode addFirstNode(ListNode head, int num)
    {
        return head;
    }
    
    // adds a new ListNode object with a value of num at the end of the 
    // linked list referenced by head; returns head
    public static ListNode addLastNode(ListNode head, int num)
    {
        return head;
    }
    
    // inserts a new ListNode object with a value of num into the linked list
    // referenced by head before the nth node in the list; returns head
    public static ListNode insertNode(ListNode head, int num, int nth)
    {
        return head;
    }
    
    //------------------------------------------------------------------//
    //    Provided methods. No coding below this line.
    //------------------------------------------------------------------//
    
    public static ListNode createList()
    {
        ListNode head = null;
        for(int i=0; i < 20; i++)
        {
            int r = (int)(Math.random() * 50) + 1;
            head = new ListNode(r, head);
        }
        return head;
    }
    
    public static void printList(ListNode head)
    {
        System.out.print("List: ");
        ListNode cur = head;
        while(cur != null)
        {
            System.out.print(cur.getValue() + " ");
            cur = cur.getNext();
        }
        System.out.println();
    }
    
    public static void main(String[] args)
    {
        System.out.println("\n-----------------------");
        System.out.println("    removeFirstNode");
        System.out.println("-----------------------");
        ListNode head = createList();            // create linked list
        printList(head);                // print linked list
        head = removeFirstNode(head);
        printList(head);
        
        System.out.println("\n-----------------------");
        System.out.println("    removeLastNode");
        System.out.println("-----------------------");
        head = createList();            // create linked list
        printList(head);                // print linked list
        head = removeLastNode(head);
        printList(head);
        
        System.out.println("\n-----------------------");
        System.out.println("     addFirstNode");
        System.out.println("-----------------------");
        head = createList();            // create linked list
        printList(head);                // print linked list
        head = addFirstNode(head, 1000);
        printList(head);
        
        System.out.println("\n-----------------------");
        System.out.println("      addLastNode");
        System.out.println("-----------------------");
        head = createList();            // create linked list
        printList(head);                // print linked list
        head = addLastNode(head, 1000);
        printList(head);
        
        System.out.println("\n-----------------------");
        System.out.println("       insertNode");
        System.out.println("-----------------------");
        head = createList();            // create linked list
        printList(head);                // print linked list
        head = insertNode(head, 1000, 9);
        printList(head);
        System.out.println();

    }
}

