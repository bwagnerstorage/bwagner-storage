import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.table.*; 

public class MyFrame extends JFrame
{
    // Instance Variables
    private InventionModel InventionModel;
    private FileStream stream;
    private JTable table;
    
    public MyFrame()
    {
        setSize(500,400);
        setTitle("Inventors");
        
        InventionModel = new InventionModel();
        table = new JTable(InventionModel);
        table.getTableHeader().addMouseListener(new TableColumnHandler());
                
        JScrollPane scrollPane = new JScrollPane(table);
                
        // Read Data File
        stream = new FileStream("inventions.txt", InventionModel);
        
        // contentPane
        Container contentPane = getContentPane();
        contentPane.add(scrollPane, BorderLayout.CENTER);
    }
    
    private class TableColumnHandler extends MouseAdapter
    {
        public void mousePressed(MouseEvent event) 
        {
           // Change Table Header of Column to Blue
           int selectedIndex = table.getColumnModel().getColumnIndexAtX(event.getX());
           TableColumn column = table.getColumnModel().getColumn(selectedIndex);
           column.setHeaderRenderer( new HeaderRenderer(table.getTableHeader(), 0) );                        
        }
        public void mouseReleased(MouseEvent event) 
        {
           // Change Table Header of Column back to default color
           int selectedIndex = table.getColumnModel().getColumnIndexAtX(event.getX());
           TableColumn column = table.getColumnModel().getColumn(selectedIndex);
           column.setHeaderRenderer( new HeaderRenderer(table.getTableHeader(), 1) ); 
           
           // Sort the selected Table Column
           String columnName = (String)column.getHeaderValue();
           InventionModel.sort(columnName);   
        }   
    }
    
    // This class is used to change the Table Header to blue when
    // the user clicks on the Header Name
    private class HeaderRenderer extends DefaultTableCellRenderer
    {
        JTableHeader myTableHeader;
        
        public HeaderRenderer(JTableHeader tableHeader, int code)
        {
            if(code == 0)
            {      
                setHorizontalAlignment(JLabel.CENTER);         
                setForeground(Color.white);
                setBackground(new Color(66,0,150));
            }
            else
            {
                setHorizontalAlignment(JLabel.CENTER);
                setForeground(tableHeader.getForeground());
                setBackground(tableHeader.getBackground());
            }
            
            setBorder(UIManager.getBorder("TableHeader.cellBorder"));
            myTableHeader = tableHeader;
            myTableHeader.resizeAndRepaint();
        }
        public Component getTableCellRendererComponent(JTable aTable, 
                                     Object aValue, 
                                     boolean aIsSelected,
                                     boolean aHasFocus, 
                                     int aRowIdx, 
                                     int aColumnIdx) 
        {    
           setText(aValue.toString());
           setFont(myTableHeader.getFont());
           return this;
        }
    }

    
}