import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.table.*; 


public class InventApplet extends JApplet
{
	// Instance Variables
	private InventorsModel inventorsModel;
	private FileStream stream;
	private JTable table;
	
	public void init()
	{
		//setSize(500,400);
		//setTitle("Inventors");
		
		inventorsModel = new InventorsModel();
		table = new JTable(inventorsModel);
		table.getTableHeader().addMouseListener(new TableColumnHandler());
		
		
		JScrollPane scrollPane = new JScrollPane(table);
				
		// Read Data File
		stream = new FileStream("inventions.txt", inventorsModel);
		
		// contentPane
		Container contentPane = getContentPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
	}
	
	private class TableColumnHandler extends MouseAdapter
	{
		public void mousePressed(MouseEvent event) 
		{
		   // Change Table Header of Column to Blue
           int selectedIndex = table.getColumnModel().getColumnIndexAtX(event.getX());
           TableColumn column = table.getColumnModel().getColumn(selectedIndex);
           column.setHeaderRenderer( new HeaderRenderer(table.getTableHeader(), 0) ); 
           
            
        }
        public void mouseReleased(MouseEvent event) 
		{
		   // Change Table Header of Column back to default color
           int selectedIndex = table.getColumnModel().getColumnIndexAtX(event.getX());
           TableColumn column = table.getColumnModel().getColumn(selectedIndex);
           column.setHeaderRenderer( new HeaderRenderer(table.getTableHeader(), 1) ); 
           
           // Sort the selected Table Column
           String columnName = (String)column.getHeaderValue();
           inventorsModel.sort(columnName);   
        }	
	}
	
	// This class is used to change the Table Header to blue when
	// the user clicks on the Header Name
	private class HeaderRenderer extends DefaultTableCellRenderer
	{
		JTableHeader myTableHeader;
		
		public HeaderRenderer(JTableHeader tableHeader, int code)
		{
			if(code == 0)
			{	   
			    setHorizontalAlignment(JLabel.CENTER);         
	            setForeground(Color.white);
	            setBackground(new Color(66,0,150));
            }
            else
            {
            	setHorizontalAlignment(JLabel.CENTER);
            	setForeground(tableHeader.getForeground());
	            setBackground(tableHeader.getBackground());
            }
            
            setBorder(UIManager.getBorder("TableHeader.cellBorder"));
	        myTableHeader = tableHeader;
	        myTableHeader.resizeAndRepaint();
        }
        public Component getTableCellRendererComponent(JTable aTable, 
                                     Object aValue, 
                                     boolean aIsSelected,
                                     boolean aHasFocus, 
                                     int aRowIdx, 
                                     int aColumnIdx) 
        {    
           setText(aValue.toString());
           setFont(myTableHeader.getFont());
           return this;
        }
	}	
}