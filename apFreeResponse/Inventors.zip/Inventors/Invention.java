import java.util.Comparator;


public class Invention
{
    // Instance Variables
    private String invention;   
    private String year;
    private String inventor;
    private String country;
    
    // Default Constructor
    public Invention()
    {
      invention ="";
      year = "";
      inventor = "";
      country = "";
    }
    
    // Second Constructor
    public Invention(String i, String y, String in, String c)
    {
      invention =i;
      year = y;
      inventor = in;
      country = c;
    }
    
    // Accessor Methods
    public String getInvention()
    {
        return invention;
    }
    
    public String getYear()
    {
        return year;
    }
    
    public String getInventor()
    {
        return inventor;
    }
    
    public String getCountry()
    {
        return country;
    }
    
    // Mutator Methods
    public void setInvention(String i)
    {
        invention = i;
    }
    
    public void setYear(String y)
    {
        year = y;
    }
    
    public void setInventor(String i)
    {
        inventor = i;
    }
    
    public void setCountry(String c)
    {
        country = c;
    }
    
    public String toString()
    {
        String str;
        str = "Invention = " + invention + "\n" +
              "Year      = " + year      + "\n" +
              "Inventor  = " + inventor  + "\n" +
              "Country   = " + country   + "\n";
        return str;
    }
}

class InventionComparator implements Comparator 
{
   public int compare(Object invention, Object anotherInvention) 
   {
      String invention1 = ((Invention) invention).getInvention().toUpperCase();
      String invention2 = ((Invention) anotherInvention).getInvention().toUpperCase();
      
      return invention1.compareTo(invention2);
   }
}

class YearComparator implements Comparator 
{
   public int compare(Object invention, Object anotherInvention) 
   {
      String invention1 = ((Invention) invention).getYear().toUpperCase();
      String invention2 = ((Invention) anotherInvention).getYear().toUpperCase();
      
      return invention1.compareTo(invention2);
   }
}

class InventorComparator implements Comparator 
{
   public int compare(Object invention, Object anotherInvention) 
   {
      String invention1 = ((Invention) invention).getInventor().toUpperCase();
      String invention2 = ((Invention) anotherInvention).getInventor().toUpperCase();
      
      return invention1.compareTo(invention2);
   }
}

class CountryComparator implements Comparator 
{
   public int compare(Object invention, Object anotherInvention) 
   {
      String invention1 = ((Invention) invention).getCountry().toUpperCase();
      String invention2 = ((Invention) anotherInvention).getCountry().toUpperCase();
      
      return invention1.compareTo(invention2);
   }
}

              
    
    