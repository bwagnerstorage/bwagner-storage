import java.io.*;

public class FileStream
{
    // Instance Variables
    FileInputStream ifstream;
    InputStreamReader reader;
    BufferedReader buffer;
    
    public FileStream(String filename, InventionModel model)
    {
        try
        {
            ifstream = new FileInputStream(filename);
            reader = new InputStreamReader(ifstream);
            buffer = new BufferedReader(reader);
        }
        catch(IOException e)
        {
            System.out.println("Error openning file");
        }
        
        try
        {
           String s1 = buffer.readLine();
           String s2 = buffer.readLine();
           String s3 = buffer.readLine();
           String s4 = buffer.readLine();
           
           while(s1 != null)
           {
               Invention inventor = new Invention(s1, s2, s3, s4);
               model.add(inventor);
               
               s1 = buffer.readLine();
               s2 = buffer.readLine();
               s3 = buffer.readLine();
               s4 = buffer.readLine();
           }
           
           ifstream.close();
        }
        catch(IOException exception)
        {
          System.out.println("Error reading file");
        }

    }
}