import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.Comparator;

class InventionModel extends AbstractTableModel
{
    // Instance Variables
    private Invention[] list;
    private final int LISTSIZE = 100;
    private int length;
    private String[] columnNames = {"Invention", "Year", "Inventor", "Country"};
    
    // Constructor
    public InventionModel()
    {
        list = new Invention[LISTSIZE];
        // Fill list with empty Textbook objects
        for(int i=0; i < LISTSIZE; i++)
        {
           list[i] = new Invention();    
        }
        length = 0;  // current number of records is 0
    }
    
    // Add Method - adds(appends) a new Inventor object to the list
    public void add(Invention i)
    {
        list[length] = i;
        fireTableRowsInserted(length, length);  // inform table of change
        length++;       
    }
    
    public void sort(String name)
    {
       if(name.equals("Invention"))
       {
          insertionSort(list, new InventionComparator());
       }
       if(name.equals("Year"))
       {
          insertionSort(list, new YearComparator());
       }
       if(name.equals("Inventor"))
       {
          insertionSort(list, new InventorComparator());
       }
       if(name.equals("Country"))
       {
          insertionSort(list, new CountryComparator());
       }
    }
    
    void insertionSort(Invention list[], Comparator comparator)
    {
      int i, j; 
      Invention index;
    
      for (i=1; i < getLength(); i++)
      {
        index = list[i];
        j = i;
        while ((j > 0) && comparator.compare(list[j-1], index) > 0)
        {
          list[j] = list[j-1];
          j = j - 1;
        }
        list[j] = index;
      }
    }
    
    // Accessor Methods
    public Invention getRecord(int index)
    {
       return list[index];
    }   
    
    public int getLength()
    {
        return length;
    } 
    
    public int getColumnCount()                // overridden from AbstractTableModel
    {
        return columnNames.length;
    }

    public int getRowCount()                   // overridden from AbstractTableModel
    {
        return length;
    }

    public String getColumnName(int col)       // overridden from AbstractTableModel
    {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) // overridden from AbstractTableModel
    {
        if(col == 0)
           return list[row].getInvention();
        if(col == 1)
           return list[row].getYear();
        if(col == 2)
           return list[row].getInventor();
        if(col == 3)
           return list[row].getCountry();
           
        return "";
    }

    public boolean isCellEditable(int row, int col) // overridden from AbstractTableModel
    {
        return false;
    }

  /*  public void setValueAt(Object value, int row, int col) // overridden from AbstractTableModel
    {
        if(col == 0)
           list[row].setInvention((String)value);
        if(col == 1)
           list[row].setYear((String)value);
        if(col == 2)
           list[row].setInventor((String)value);
        if(col == 3)
           list[row].setCountry((String)value);
           
        fireTableCellUpdated(row, col); // inform Table of change
    } */
}