import java.awt.*;
import javax.swing.*;

public class InventorsApp
{
    public static void main(String[] args)
    {
       MyFrame frame = new MyFrame();
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.show();    
    }
}
