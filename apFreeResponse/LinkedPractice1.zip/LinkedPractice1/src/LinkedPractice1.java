import java.util.*;

public class LinkedPractice1
{   
    private ListNode head;
    
    // creates a linked list of 10 integers in the range of 1 to 50
    // and assigns the list's reference(address) to the variable head
    public void createList()
    {

    }
    
    // displays the linked list referenced by the variable head
    // the numbers in the list should be displayed horizontally
    public void printList()
    {

    }
    
    // calculates and returns the sum of all the numbers stored in the 
    // linked list reference by the variable head
    public int sumList()
    {
        return 0;
    }
    
    // displays all the numbers in the linked list that have a value greater
    // than or equal to 5. Numbers are displayed horizontally.
    public void filterList()
    {    

    }  
    
    public static void main(String[] args)
    {
        LinkedPractice1 app = new LinkedPractice1();
        app.createList();
        app.printList();
        System.out.println("\nsum = " + app.sumList() + "\n");
        app.filterList();
    }
}

