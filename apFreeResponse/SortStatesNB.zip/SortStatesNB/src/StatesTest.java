public class StatesTest
{
    public StatesTest()
    {
        UnitedStates us = new UnitedStates();
    }

    public static void main(String[] args)
    {
        StatesTest test = new StatesTest();
    }
}