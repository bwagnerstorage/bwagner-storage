public class StepTrackerDriver
{
    public static void main(String[] args)
    {
        StepTracker tr = new StepTracker(10000);
        
        System.out.println("Active day consists of at least 10,000 steps.");
        System.out.println("Current Days Active: " + tr.activeDays());
        System.out.println("Average Number of Steps: "+ tr.averageSteps());
        System.out.println();
        tr.addDailySteps(9000);
        System.out.println("9000 steps today, not enough to meet active goal.");
        System.out.println();
        tr.addDailySteps(5000);
        System.out.println("5000 steps today, not enough to meet active goal.");
        System.out.println("Current Days Active: " + tr.activeDays());
        System.out.println("Average Number of Steps: "+ tr.averageSteps());
        System.out.println();
        tr.addDailySteps(13000);
        System.out.println("13000 steps today, met active goal!");
        System.out.println("Current Days Active: " + tr.activeDays());
        System.out.println("Average Number of Steps: "+ tr.averageSteps());
        System.out.println();
        tr.addDailySteps(23000);
        System.out.println("23000 steps today, met active goal!");
        System.out.println();
        tr.addDailySteps(1111);
        System.out.println("1111 steps today, not enough to meet active goal.");
        System.out.println("Current Days Active: " + tr.activeDays());
        System.out.println("Average Number of Steps: "+ tr.averageSteps());   
    }
}