public class CodeWordCheckerDriver
{
    public static void main(String[] args)
    {
        CodeWordChecker sc1 = new CodeWordChecker(5, 8, "$");
        
        System.out.println("String = \"$\"");
        System.out.println("sc1.isValid(\"happy\") = " +  sc1.isValid("happy"));
        System.out.println("sc1.isValid(\"happy$\") = " +  sc1.isValid("happy$"));
        System.out.println("sc1.isValid(\"Code\") = " +  sc1.isValid("Code"));
        System.out.println("sc1.isValid(\"happyCode\") = " +  sc1.isValid("happyCode"));
        
        CodeWordChecker sc2 = new CodeWordChecker("pass");
        
        System.out.println();
        System.out.println("String = \"pass\"");
        System.out.println("sc2.isValid(\"MyPass\") = " +  sc2.isValid("MyPass"));
        System.out.println("sc2.isValid(\"Mypassport\") = " +  sc2.isValid("MypassPort"));
        System.out.println("sc2.isValid(\"happy\") = " +  sc2.isValid("happy"));
        System.out.println("sc2.isValid(\"1,000,000,000,000,000\") = " +  sc2.isValid("1,000,000,000,000,000"));
    }
}
