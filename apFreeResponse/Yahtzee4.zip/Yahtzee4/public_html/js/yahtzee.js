function yahtzee() {
    this.context = null;
    this.dice = [];
    this.images = [];
    this.loadCount = 0;
    this.rolled = false;
    this.numRolls = 3;
    this.yahtzeeCount = -1;
    this.yahtzeeBonus = 0;
    this.gameCount = 0;
    this.upperCount = 0;
};

yahtzee.prototype.initialize = function() {
    this.context = document.getElementById("myCanvas").getContext("2d");
    this.loadImages();
};

yahtzee.prototype.loadImages = function() {
    for(var i=0; i < 6; i++)
    {
        var img = new Image();
        (function(that, image, j) {
        image.onload = function() {
            that.images[j] = image;
            that.loadCount++;
            if(that.loadCount === 6)
                that.buildDice();
        };
    })(this, img, i);  // closure
    var filename = "images/d"+ (i+1) + ".png";
    img.src = filename;  
    }   
};

yahtzee.prototype.buildDice = function() {
    for(var i = 0; i < 5; i++)
    {
        this.dice[i] = {value : i, hold : false};
    }
};

yahtzee.prototype.draw = function() {
    var x = 0;
    for(var i = 0; i < this.dice.length; i++)
    { 
        var img = this.images[this.dice[i].value - 1];
        this.context.drawImage(img, x, 10, 108, 108);
        x+=120;
    } 
};

yahtzee.prototype.rollDice = function()
{   
    var that = this;  // store current this object
    if(this.numRolls > 0 && !this.rolled) {
        
        var current = new Date();  // current time in millis
        var rollTime = current.getTime() + 2000;  // current time + 2 seconds
        
        that.rolled = true;  // started roll sequence

            // spin dice images every 1/10 of a second for 2 seconds
            var timer = setInterval(function(){ spinDice(); }, 100); 
            
            // inner function
            function spinDice() {
                for(var i = 0; i < 5; i++)
                {
                    if(that.dice[i].hold === false)
                    {
                        var index = Math.floor(Math.random() * 6) + 1;
                        that.dice[i].value = index;
                    }
                }

            that.draw();  // draw dice

            if(new Date().getTime() > rollTime)  // can't roll while rolling
            {
                that.rolled = false;
                clearInterval(timer);  // stop spinning after 2.5 seconds
                
                that.endTurn(that);
            }
        }
        
        that.numRolls--;
        document.getElementById("rolls").innerHTML = that.numRolls;
    }
};

yahtzee.prototype.calculateUpperTotals = function()
{

};

yahtzee.prototype.calculateLowerTotals = function()
{
    
};

yahtzee.prototype.makeSelection = function(selection)
{
    var total = 0; 
    
    // upper section 1-6)
    for(var a = 1; a <= 6; a++)
    {
        if(selection === a)
        {    
            for(var i = 0; i < 5; i++)
            {
                if(this.dice[i].value === a)
                {
                    total += a;
                }
            }
        }      
    }

  if(selection === 7 || selection === 8)
  {
      if(this.ofAKindTest(4))  // four of a kind test
      {
            for(var i = 0; i < 5; i++)
            {
                total += this.dice[i].value;
            }
      }
      else if(this.ofAKindTest(3))  // three of a kind test
      {
            for(var i = 0; i < 5; i++)
            {
                total += this.dice[i].value;
            }
      }
  }
  if(selection === 9)
  {
      if(this.fullHouseTest())
          total = 25; 
  }
  
  if(selection === 10)
  {
      if(this.smallStraightTest())
          total = 30;
  }
  
  if(selection === 11)
  {
      if(this.largeStraightTest())
          total = 40;
  }
  
  if(selection === 12)
  {
      if(this.yahtzeeTest(this))
      {
          total = 50;
      }
  }
  
  if(selection === 13)
  {
      for(var i = 0; i < 5; i++)
      {
          total += this.dice[i].value;
      }
  }
  
  // remove click button and replace it with total
  var elem = document.getElementById("p" + selection);
  elem.removeChild(elem.getElementsByTagName('button')[0]);
  elem.innerHTML = total;
  
};

yahtzee.prototype.yahtzeeTest = function(obj)
{
    var num = obj.dice[0].value;
    for(var i=1; i < 5; i++)
    {
        if(obj.dice[i].value !== num)
            return false;
    }
    return true;
};

yahtzee.prototype.removeDuplicates = function()
{
    var string = "";
    for(var i = 1; i <= 6; i++)
    {
        for(var j = 0; j < 5; j++)
        {
            if(this.dice[j].value === i)
            {
                string += i;
                break;
            }
        }
    }
    return string;
};

yahtzee.prototype.smallStraightTest = function()
{
    var p1 = "1234";
    var p2 = "12345";
    var p3 = "12346";
    var p4 = "2345";
    var p5 = "23456";
    var p6 = "3456";
    var p7 = "13456";
    
    var key = this.removeDuplicates();
    
    if(key === p1 || key === p2 || key === p3 || key === p4 || 
       key === p5 || key === p6 || key === p7)
    {
        return true;
    }
    return false;
};

yahtzee.prototype.largeStraightTest = function()
{
    var p1 = "12345";
    var p2 = "23456";
    
    var key = this.removeDuplicates();
    
    if(key === p1 || key === p2)
    {
        return true;
    }
    return false;
};

yahtzee.prototype.ofAKindTest = function(key)
{
    var count;
    
    for(var i=0; i < 5; i++)
    {
        count = 0;
        var num = this.dice[i].value;
        for(var j=0; j < 5; j++)
        {
            if(num === this.dice[j].value)
            {
                count ++;
                if(count === key)
                    return true;
            }
        }
    }
    return false;
};

yahtzee.prototype.fullHouseTest = function()
{
    var threeCount;
    var threeValue = 0;
    var twoValue1 = 0;
    var twoValue2 = 0;
    
    for(var i=0; i < 5; i++)
    {
        threeCount = 0;
        var num = this.dice[i].value;
        for(var j=0; j < 5; j++)
        {
            if(i !== j && num === this.dice[i].value)
            {
                threeCount ++;
                if(threeCount === 3)
                    threeValue = this.dice[i].value;
            }
        }
    }
    
    for(var i=0; i < 5; i++)
    {
        var num = this.dice[i].value;
        if( num !== threeValue)
        {
            if(twoValue1 === 0)
            {
                twoValue1 = num;
            }
            else
            {
                twoValue2 = num;
            }
        }
    }
    
    if(twoValue1 === twoValue2)
        return true;
    else
        return false;
};

yahtzee.prototype.holdDice = function(dieNumber)
{
    var die = document.getElementById("hold" + dieNumber);
    
    if(this.dice[dieNumber].hold === false)
    {
        this.dice[dieNumber].hold = true;
        die.style.backgroundColor = "gold";
    }
    else
    {
        this.dice[dieNumber].hold = false;
        die.style.backgroundColor = "lightgoldenrodyellow";
    }
};

yahtzee.prototype.endTurn = function(obj)
{
    if(obj.numRolls === 0)
    {
        for(var i = 0; i < 5; i++)
        {
            obj.dice[i].hold = true;
            var die = document.getElementById("hold" +(i));
            die.style.backgroundColor = "gold";
        }
        obj.disableButtons();
    }
};

yahtzee.prototype.resetTurn = function()
{
    this.isTurnOver = false;
    this.numRolls = 3;
    document.getElementById("rolls").innerHTML = this.numRolls;
    for(var i = 0; i < 5; i++)
    {
        this.dice[i].hold = false;
        var die = document.getElementById("hold" + i);
        die.style.backgroundColor = "lightgoldenrodyellow";
    }
    this.enableButtons();
    this.hideDice();
};

yahtzee.prototype.hideDice = function()
{
    this.context.clearRect(0,0,590,120); 
};

yahtzee.prototype.disableButtons = function()
{
    document.getElementById("rollButton").disabled = true;
    for(var i = 0; i < 5; i++)
    {
        var die = document.getElementById("hold" +(i));
        die.disabled = true;
    }
};

yahtzee.prototype.enableButtons = function()
{
    document.getElementById("rollButton").disabled = false;
    for(var i = 0; i < 5; i++)
    {
        var die = document.getElementById("hold" +(i));
        die.disabled = false;
    }
};







