import java.util.*;

public class Problem2
{
	public static void main(String[] args)
	{
		System.out.println("***********");
		System.out.println(" Problem 2");
		System.out.println("***********");
		
		Scanner keyboard = new Scanner(System.in);
		
		// - Write solution below this line - //




	}
}