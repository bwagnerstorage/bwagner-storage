public interface College 
{ 
   String getName(); 
   String getRegion(); 
   int getTuition(); 
   void setTuition(int newTuition);
}