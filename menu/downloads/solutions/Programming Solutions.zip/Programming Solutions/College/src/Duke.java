public class Duke implements College
{
   // instance variables
   private int tuition;
   
   // constructor
   public Duke(int t)
   {
        tuition = t;
   }
   public String getName()
   {
        return "Duke University";
   } 
   public String getRegion()
   {
        return "East";
   }
   public int getTuition()
   {
        return tuition;
   } 
   public void setTuition(int newTuition)
   {
        tuition = newTuition;
   }
}