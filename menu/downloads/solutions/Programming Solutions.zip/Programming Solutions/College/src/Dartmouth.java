public class Dartmouth implements College
{
   // instance variables
   private int tuition;
   
   // constructor
   public Dartmouth(int t)
   {
        tuition = t;
   }
   public String getName()
   {
        return "Dartmouth College";
   } 
   public String getRegion()
   {
        return "Northeast";
   }
   public int getTuition()
   {
        return tuition;
   } 
   public void setTuition(int newTuition)
   {
        tuition = newTuition;
   }
}