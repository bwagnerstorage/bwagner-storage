public class Spelman implements College
{
   // instance variables
   private int tuition;
   
   // constructor
   public Spelman(int t)
   {
        tuition = t;
   }
   public String getName()
   {
        return "Spelman College";
   } 
   public String getRegion()
   {
        return "Southeast";
   }
   public int getTuition()
   {
        return tuition;
   } 
   public void setTuition(int newTuition)
   {
        tuition = newTuition;
   }
}