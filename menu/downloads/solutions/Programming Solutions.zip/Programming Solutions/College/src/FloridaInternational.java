public class FloridaInternational implements College
{
   // instance variables
   private int tuition;
   
   // constructor
   public FloridaInternational(int t)
   {
        tuition = t;
   }
   public String getName()
   {
        return "Florida International University";
   } 
   public String getRegion()
   {
        return "Southeast";
   }
   public int getTuition()
   {
        return tuition;
   } 
   public void setTuition(int newTuition)
   {
        tuition = newTuition;
   }
}