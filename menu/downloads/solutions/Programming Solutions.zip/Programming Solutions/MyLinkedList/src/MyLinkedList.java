public class MyLinkedList<E> implements MyList<E>
{
    private ListNode head;
    private ListNode tail;
    private ListNode cur;
    private ListNode prev;
    private int size;

    public MyLinkedList()
    {
        head = null;
        tail = null;
        cur = null;
        prev = null;
        size = 0;
    }

    public void add(E item)
    {

    }

    public void add(int index, E item)
    {

    }

    public void remove(int index)
    {

    }

    public E get(int index)
    {

    }

    public void set(int index, E item)
    {

    }

    public int size()
    {

    }
}