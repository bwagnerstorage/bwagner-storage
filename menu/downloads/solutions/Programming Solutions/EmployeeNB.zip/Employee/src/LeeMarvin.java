public class LeeMarvin implements Employee 
{ 
   public int getAge()
   {
        return 50;
   }
   public int getYearsOnJob()
   {
        return 15;
   } 
   public double getSalary()
   {
        return 38000;
   }
   public int getID()
   {
        return 700;
   }
}