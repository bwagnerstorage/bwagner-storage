public class JimmyStewart implements Employee 
{ 
   public int getAge()
   {
        return 60;
   }
   public int getYearsOnJob()
   {
        return 40;
   } 
   public double getSalary()
   {
        return 80000;
   }
   public int getID()
   {
        return 200;
   }
}