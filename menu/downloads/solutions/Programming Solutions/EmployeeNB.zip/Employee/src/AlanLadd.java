public class AlanLadd implements Employee 
{ 
   public int getAge()
   {
        return 68;
   }
   public int getYearsOnJob()
   {
        return 37;
   } 
   public double getSalary()
   {
        return 64000;
   }
   public int getID()
   {
        return 400;
   }
}