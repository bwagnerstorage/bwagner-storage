public class LinkedQueue<E> implements Queue<E>
{
    // instance variables
    private ListNode front = null;
    private ListNode back = null;

    public LinkedQueue()
    {
        front = null;
        back = null;
    }

    public void enqueue(E item)
    {

    }

    public E dequeue()
    {

    }

    public E front()
    {

    }

    public boolean isEmpty()
    {

    }

    public String toString()
    {

    }
}