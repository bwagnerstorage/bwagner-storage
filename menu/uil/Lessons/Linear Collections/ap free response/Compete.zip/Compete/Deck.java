import java.util.*;

public class Deck
{
	public static final int MAX_CARDS = 52;
	private HashSet <Card> deck;
	
	public Deck()
	{
		deck = new HashSet <Card>();
		Card[] cards = new Card[MAX_CARDS];
		int count = 0;
		for(int i=1; i <= MAX_CARDS/4; i++)
		{
		   for(int j=1; j <= 4; j++)
		   {
		   	  cards[count] = new Card(i);
		      count++;	
		   }
	
		}
		
		shuffle(cards);
	}
	
	public void shuffle(Card[] cards)
	{ 
		HashSet<Integer> indices = new HashSet<Integer>();
		
	    while(indices.size() < MAX_CARDS)
	    {
	    	int index = (int)(Math.random() * MAX_CARDS);
	    	while(indices.contains(index) == true)
	    	{
	    		index = (int)(Math.random() * MAX_CARDS);
	    	}
	    	indices.add(index);
	    	deck.add(cards[index]);
	    }	   
	}
	
	public HashSet<Card> getCards()
	{
	  return deck;	
	}
	
	public void display()
	{
		Iterator iter = deck.iterator();
		while(iter.hasNext())
		{
			Card card = (Card)iter.next();
			System.out.println(card.getValue());
		}
	}
}