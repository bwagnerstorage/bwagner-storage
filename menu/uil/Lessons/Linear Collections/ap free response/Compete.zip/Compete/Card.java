public class Card
{
	private int value;
	
	public Card(int v)
	{
	   value = v;	
	}
	
	public int getValue()
	{
	   return value;	
	}
}