import java.util.*;

public class RadixSort
{
	public  RadixSort()
	{
	   ArrayList<Integer> list = new ArrayList<Integer>();
	   list.add(20); list.add(47); list.add(13); list.add(88);
	   list.add(52); list.add(71); list.add(97); list.add(5);
	   list.add(35); list.add(64);
	   
	   printList(list);
	   ArrayList<Integer> sortedList = radixSort(list, 3);
	   System.out.println();
	   printList(sortedList);
	}
	
	// precondition: number = 0; k = 0 
    // postcondition: returns kth digit of number
	public int getDigit(int number, int k)
	{
	   int remainder = 0;
	   Integer n = new Integer(number);
	   String s = n.toString();
	   if(s.length() < k)
	     return 0;
	   for(int i=0; i < k; i++)
	   {
	   	  remainder = number % 10;
	   	  number = number / 10;
	   }	
	   return remainder;
	}
	
	// part (a)
	// precondition: all values in L are positive;
    //     k >= 0
    // postcondition: Step 1 of the Radix sort algorithm for the digit
    //     at position k has been completed
	public ArrayList<Queue<Integer>> itemsToQueues(ArrayList<Integer> L, int k)
	{


	} 
	
	// part (b)
	// precondition: QA.size() == 10; numVals is the total number of
    //    integers in all the queues in QA
    // postcondition: returns an ArrayList of length numVals that contains
    //    the integers from QA[0] through QA[9] in the order
    //    in which they were stored in the queues;
    //    the queues in QA are empty
	public ArrayList<Integer> queuesToArray(ArrayList<Queue<Integer>> QA, int numVals)
	{


	}
	
	// part (c)
	// precondition: L.size() > 0; all values in L are positive; 
    //    the largest value in L has numDigits digits;
    // postcondition: returns an Arraylist of values, sorted in 
    //    increasing order
	public ArrayList<Integer> radixSort(ArrayList<Integer> L, int numDigits)
	{


	}
	
	public void printList(ArrayList<Integer> list)
	{
	   for(int i =0; i < list.size(); i++)
	   {
	   	  System.out.print(list.get(i) + " ");
	   }	
	   System.out.println();
	}
	
	public static void main(String[] args)
	{
		RadixSort app = new RadixSort();
	}
}