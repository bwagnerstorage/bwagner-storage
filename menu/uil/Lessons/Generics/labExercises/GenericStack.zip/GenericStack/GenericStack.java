public class GenericStack implements Stack
{
	private ListNode head;
	
	public GenericStack()
	{
	   head = null;	
	}
	
	// adds an item to the top of the stack
	public void push(Object item)
	{
	   if(head == null)
	   {
	   	  head = new ListNode(item, null);
	   }
	   else
	   {
	   	   ListNode temp = new ListNode(item, head);
	   	   head = temp;
	   }   	
	}
	
	// removes an item from the top of the stack
	public Object pop()
	{
	   ListNode temp = head;
	   head = head.getNext();
	   return temp.getValue();
	}
	
	// returns the top item in the stack without removing it
	public Object top()
	{
		return head.getValue();
	}
	
	// returns true if the stack is empty; otherwise returns false
	public boolean isEmpty()
	{
	   if(head == null)
	     return true;
	   else
	     return false;	
	}
	
   public String toString()
   {
   	  String str="";
   	  ListNode cur = head;
   	  while(cur != null)
   	  {
   	  	 str += cur.getValue() + "\n";
   	  	 cur = cur.getNext();
   	  }
   	  return str;
   }
}