public class Tester
{
	public static void main(String[] args)
	{
		GenericStack<String> stack = new GenericStack<String>();
		
		System.out.println();
		System.out.println("Test - push");
		System.out.println("-----------");
		stack.push("red");
		stack.push("white");
		stack.push("blue");
		
		System.out.println();
		System.out.println("Test - top");
		System.out.println("----------");
		System.out.println(stack.top());
		
		System.out.println();
		System.out.println("Test - pop and isEmpty");
		System.out.println("----------------------");
		while(!stack.isEmpty())
		{
			System.out.println(stack.pop());
		}
		
		System.out.println();
		System.out.println();
	
	}
}