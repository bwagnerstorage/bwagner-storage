import java.util.*;

public interface GenericSortedSet
{
    // returns the number of items in set
    int size();
    
    // returns the first (lowest) element currently in this sorted set.
    Object first();
    
    // returns the last (highest) element currently in this sorted set
    Object last();
    
    // returns a portion of this sorted set whose elements 
    // range from fromElement, inclusive, to toElement, inclusive.
    GenericSortedSet subSet(Comparable fromElement, Comparable toElement);
    
    // returns an iterator on the set
    Iterator iterator();
}