import java.util.*;

public class Tester
{
	public static void main(String[] args)
	{
		GenericTreeSet<String> set = new GenericTreeSet<String>();
		
		set.add("M");
		set.add("D");
		set.add("B");
		set.add("R");
		set.add("U");
		set.add("T");
		set.add("F");
		set.add("H");
		set.add("Y");
		set.add("X");
		set.add("Z");
		set.add("Q");
		
		System.out.println();
		System.out.println("================");
		System.out.println("   String Set");
		System.out.println("================");
		
		// Tree Structure
		System.out.println();
		System.out.println("   Tree Structure");
		System.out.println("--------------------");
		System.out.println(set);
		
		System.out.println();
		System.out.println("Test - iterator");
		System.out.println("---------------");
		
		Iterator iter = set.iterator();
		while(iter.hasNext())
		{
			System.out.print(iter.next() + " ");
		}
		System.out.println();
		
		GenericTreeSet<Integer> set2 = new GenericTreeSet<Integer>();
		
		set2.add(8);
		set2.add(4);
		set2.add(2);
		set2.add(7);
		set2.add(10);
		set2.add(1);
		
		System.out.println();
		System.out.println("================");
		System.out.println("   Integer Set");
		System.out.println("================");
		// Tree Structure
		System.out.println();
		System.out.println("   Tree Structure");
		System.out.println("--------------------");
		System.out.println(set2);
		
		System.out.println();
		System.out.println("Test - iterator");
		System.out.println("---------------");
		
		Iterator iter2 = set2.iterator();
		while(iter2.hasNext())
		{
			System.out.print(iter2.next() + " ");
		}
		System.out.println();
	}
}