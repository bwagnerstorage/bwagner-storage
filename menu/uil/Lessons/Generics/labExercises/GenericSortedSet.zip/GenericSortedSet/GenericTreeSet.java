import java.util.*;

public class GenericTreeSet extends BinaryTree implements GenericSortedSet
{
	public GenericTreeSet()
	{
		setRoot(null);
	}
	public GenericTreeSet(TreeNode node)
	{
		setRoot(node);
	}
	// returns the number of items in set
	public int size()
	{
	   return size(getRoot());	
	}
	
	private int size(TreeNode root)
	{
		if(root == null)
			return 0;
		return 1 + size(root.getLeft()) + size(root.getRight());
	}
	
	public TreeNode contains(Comparable obj)
	{
		return contains(getRoot(), obj);
	}
	
	private TreeNode contains(TreeNode root, Comparable obj)
	{
      if(root == null)
         return null;
      else
      {
         if(obj.compareTo(root.getValue()) == 0)
            return root;
         else if(obj.compareTo(root.getValue()) < 0)
            return contains(root.getLeft(), obj);
         else
            return contains(root.getRight(), obj);
      }
	}
	
   public void add(Comparable item)
   {
   	  setRoot(add(getRoot(), item));
   }
   
   private TreeNode add(TreeNode root, Comparable item)
   {
   	  if(root == null)
   	  {
   	  	 return new TreeNode(item, null, null);
   	  }
   	 
   	  if(item.compareTo(root.getValue()) < 0)
   	     root.setLeft(add(root.getLeft(), item));
   	  if(item.compareTo(root.getValue()) > 0) 
   	     root.setRight(add(root.getRight(), item));
   	     
   	  return root;
    }
	
   public TreeNode remove(Comparable key)
   {
      return remove(key, getRoot());
   }
   
   private TreeNode remove(Comparable key, TreeNode tree) 
   {
        if (tree == null) 
             return null; // empty tree so nothing to remove
        else if(key.compareTo(tree.getValue()) < 0) 
        {           
           // search for key in left sub-tree. Set left-sub tree to 
           // result of recursive call to delete from left-subtree
           tree.setLeft(remove(key, tree.getLeft()));
        } 
        else if (key.compareTo(tree.getValue()) > 0) 
        { 
           // search for key in right sub-tree. Set right-sub tree to
           // result of recursive call to delete from right-subtree
           tree.setRight(remove(key, tree.getRight()));
        } 
        else if (tree.getLeft() != null && tree.getRight() != null) 
        {
           // tree refers to node to be deleted and it has no null children
           // find the in-order successor, disconnect it and return its
           // data value, setting this as the new data element of tree
           tree.setValue(disconnectSucc(tree));
        } 
        else if (tree.getLeft() == null) 
        {
           // tree refers to node to be deleted and its left child is 
           // null so set tree to refer to right child
           tree = tree.getRight();
        } 
        else 
        {
          // tree refers to node to be deleted and its left child 
          // is not null so set tree to refer to left child
          tree = tree.getLeft();
        }
        return tree;
  }
  
  // helper for remove method
  private Comparable disconnectSucc(TreeNode node) 
  {
     TreeNode succParent = node;
     TreeNode succ = node;
     TreeNode curr = node.getRight();
     
     // locate successor
     // The successor is leftmost node in the deleted nodes
     // right sub-tree
     while (curr != null) 
     {
       succParent = succ;
       succ = curr;
       curr = curr.getLeft();
     }
     
     // test if successor is right child of its parent node
     if (succ == succParent.getRight()) 
     {
       // set right child of parent to right child of successor
       succParent.setRight(succ.getRight());
     } 
     else 
     {
       // set left child of parent to right child of successor
       succParent.setLeft(succ.getRight());
     }
     return (Comparable)succ.getValue();
   }
	
	// returns the first (lowest) element currently in this sorted set.
	public Object first()
	{
	   TreeNode current = getRoot();
	   TreeNode prev = current;
	   while(current != null)
	   {
	   	  prev = current;
	   	  current = current.getLeft();
	   }
	   return prev.getValue();	
	}
	
	// returns the last (highest) element currently in this sorted set
	public Object last()
	{
	   TreeNode current = getRoot();
	   TreeNode prev = current;
	   while(current != null)
	   {
	   	  prev = current;
	   	  current = current.getRight();
	   }
	   return prev.getValue();	
	}
	
	public GenericTreeSet subSet(Comparable fromElement, Comparable toElement)
	{
		return subSet(contains((Comparable)fromElement), toElement);
	}
	
	private GenericTreeSet subSet(TreeNode root, Comparable toElement)
	{
		GenericTreeSet newSet = new GenericTreeSet(new TreeNode(root.getValue(), null, null));
		TreeNode newRoot = newSet.getRoot();
		TreeNode current = newRoot;
		
		while(root != null && toElement.compareTo(root.getValue()) != 0)
		{	
		   if(toElement.compareTo(root.getValue()) < 0)
		   {
		   	  if(root.getLeft() != null)
		   	      current.setLeft(new TreeNode(root.getLeft().getValue(), null, null));
		   	  else
		   	  	  current.setLeft(null);
		   	  
		   	  current = current.getLeft();	  
		   	  root = root.getLeft();
		   }
		   if(toElement.compareTo(root.getValue()) > 0)
		   {
		   	  if(root.getRight() != null)
		   	     current.setRight(new TreeNode(root.getRight().getValue(), null, null));
		   	  else
		   	  	 current.setRight(null);
		   	  	 
		   	  current = current.getRight();
		   	  root = root.getRight();
		   }     	      
		}
		return newSet;
	}	
	
   /******************************************/
   /*             Iterator Methods           */
   /******************************************/
    
    public Iterator iterator()
    {
        return new MyIterator();
    }
    
    // private inner class 
    private class MyIterator implements Iterator
    {
        // instance variables
        private TreeNode root;
        private TreeNode current;
        private Stack<TreeNode> stack;
        
        public MyIterator()
        {
           root = getRoot();
           stack = new Stack<TreeNode>();
           pushLeft(root);
        }
        
        // Iterator methods
        
        // returns true if the iteration has more elements. 
        public boolean hasNext()
        {
           return !stack.isEmpty();
        }
        
        // returns the next element in the iteration
        public Object next()
        {
            TreeNode current = stack.pop();
            pushLeft(current.getRight());
	        return current.getValue();
        }
        
        private void pushLeft(TreeNode node)
        {
        	while (node != null) 
	        {
	            stack.push(node);
	            node = node.getLeft();
	        }
        }
        
        // not implemented
        public void remove()
        {
            throw new UnsupportedOperationException();
        }
    }
	
	
   /***********************************/
   /*            toString             */
   /***********************************/ 
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(getRoot(), 0);
   }  
   
   private String toString(TreeNode tree, int level)
   {
      String str = "";
      if(tree != null)
      {
        str += toString(tree.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "    ";
        }
        str += tree.getValue().toString() + "\n";
        str += toString(tree.getLeft(), level + 1);
      }
      
      return str;
   }  
}