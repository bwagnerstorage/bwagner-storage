public class Tester
{
	public static void main(String[] args)
	{
       MaxHeap heap = new MaxHeap();
       
       heap.insert(13);
       heap.insert(50);
       heap.insert(25);
       heap.insert(38);
       heap.insert(9);
       heap.insert(77);
       heap.insert(95);
       heap.insert(49);
       
       System.out.println("Heap = "+ heap);
       System.out.println("Size = "+ heap.size());
       System.out.println("Max = " + heap.removeMax());
       System.out.println();
       System.out.println("Heap = "+ heap);
       System.out.println("Size = "+ heap.size());
       System.out.println("Max = " + heap.removeMax());
       System.out.println();
       System.out.println("Heap = "+ heap);
       System.out.println("Size = "+ heap.size());
       System.out.println("Max = " + heap.removeMax());
       System.out.println();
       System.out.println("Heap = "+ heap);
       System.out.println("Size = "+ heap.size());
       System.out.println("Max = " + heap.removeMax());
       System.out.println();
       System.out.println("Heap = "+ heap);
       System.out.println("Size = "+ heap.size());
       System.out.println("Max = " + heap.removeMax());
       System.out.println();
       System.out.println("Heap = "+ heap);
       System.out.println("Size = "+ heap.size());
       System.out.println("Max = " + heap.removeMax());
       System.out.println();
       System.out.println("Heap = "+ heap);
       System.out.println("Size = "+ heap.size());
       System.out.println("Max = " + heap.removeMax());
       System.out.println();
       System.out.println("Heap = "+ heap);
       System.out.println("Size = "+ heap.size());
       System.out.println("Max = " + heap.removeMax());
       System.out.println();
	}
}