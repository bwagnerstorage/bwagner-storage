public class HeapSort
{
	private static int size=0;
	
	// Performs a sort using heap sort algorithm
	// Step 1: Build heap (convert input array into heap)
	// Step 2: Continually removes the largest number from
	//    the heap(root) and stores it at the end of the array.
	//    After each largest number is removed the heap is 
	//    rebuilt without including the sorted data 
	//    at the end of the array.
	public static void sort(int[] heap)
	{


	}
	
    // helper methods
    
    
}