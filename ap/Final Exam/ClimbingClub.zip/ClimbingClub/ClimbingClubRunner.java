public class ClimbingClubRunner
{
	public static void main(String[] args)
	{
		ClimbingClub club1 = new ClimbingClub();

		club1.addClimb1("Monadnock", 274);
		club1.addClimb1("Whiteface", 301);
		club1.addClimb1("Algonquin", 225);
		club1.addClimb1("Monadnock", 344);

		System.out.println("=============");
		System.out.println("Test addClimb");
		System.out.println("=============");
		System.out.println();
		System.out.println("Part A");
		System.out.println("-------");
		System.out.println(club1);
		System.out.println();

		ClimbingClub club2 = new ClimbingClub();

		club2.addClimb2("Monadnock", 274);
		club2.addClimb2("Whiteface", 301);
		club2.addClimb2("Algonquin", 225);
		club2.addClimb2("Monadnock", 344);

		System.out.println("Part B");
		System.out.println("-------");
		System.out.println(club2);
		System.out.println();
	}
}