public class HorseBarnRunner
{
	public static void main(String[] args)
	{
		Horse[] spaces = new Horse[10];

		spaces[0] = new MyHorse("Trigger",1340);
		spaces[2] = new MyHorse("Silver",1210);
		spaces[3] = new MyHorse("Lady",1575);
		spaces[5] = new MyHorse("Patches",1350);
		spaces[9] = new MyHorse("Dukes",1410);

		HorseBarn barn = new HorseBarn(spaces);

		System.out.println("===================");
		System.out.println("Test findHorseSpace");
		System.out.println("===================");
		System.out.println("Trigger\'s space = " + barn.findHorseSpace("Trigger"));
		System.out.println("Silver\'s space = " + barn.findHorseSpace("Silver"));
		System.out.println("Coco\'s space = " + barn.findHorseSpace("Coco"));
		System.out.println();

		System.out.println("===================");
		System.out.println("Test consolidate");
		System.out.println("===================");
		System.out.println();
		System.out.println("Original List");
		System.out.println("-------------");
		System.out.println(barn);
		System.out.println();

		barn.consolidate();

		System.out.println("Consolidated List");
		System.out.println("-----------------");
		System.out.println(barn);
		System.out.println();



	}
}