import greenfoot.*;

/**
 * Write a description of class Explosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explosion extends AnimatedActor
{
    public Explosion(String fileName, int numFrames, int frameWidth, int frameHeight)
    {
        super(fileName, numFrames, frameWidth, frameHeight);
    }
}
