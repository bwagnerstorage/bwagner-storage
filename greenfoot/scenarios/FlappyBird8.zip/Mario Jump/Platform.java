import greenfoot.*;
import java.awt.*;


public class Platform extends Actor
{
    public boolean topCollision(Actor actor) 
    {
        int actorBottomLeftX = actor.getX() - 32/2;
        int actorBottomLeftY = actor.getY() + 38/2;
        int actorBottomRightX = actor.getX() + 32/2;
        int actorBottomRightY = actor.getY() + 38/2;
        
        int platformTopLeftX = getX() - getImage().getWidth()/2;
        int platformTopLeftY = getY() - getImage().getHeight()/2;
        int platformTopRightX = getX() + getImage().getWidth()/2;
        int platformTopRightY = getY() - getImage().getHeight()/2;
        
        Rectangle actorRect = new Rectangle(actorBottomLeftX, actorBottomLeftY, 32, 5);
        Rectangle platformRect = new Rectangle(platformTopLeftX, platformTopLeftY, 
                                               getImage().getWidth(), 5);
                                            
        return actorRect.intersects(platformRect);

    }
}
