import greenfoot.*;

/**
 * Write a description of class Car here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Car extends Actor
{
    int speed = 1;
    
    public void act() 
    {

    }    
}
