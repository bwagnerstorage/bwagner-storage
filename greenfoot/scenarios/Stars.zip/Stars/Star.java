import greenfoot.*;

/**
 * Write a description of class Star here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Star extends Actor
{
    private final int SIZE = 3;   // size of star
    private int speed = 0;        // speed of star
    
    public Star()
    {

       
    }
    
    public void act() 
    {
         
    }    
}
