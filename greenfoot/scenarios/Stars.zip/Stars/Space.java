import greenfoot.*;
import java.awt.Graphics2D;
import java.awt.image.*;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Space extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Space()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        
        
    }
    
    // This method creates stars at random locations within the world
    // The number of stars created is equal to the value of the parameter howMany
    public void addStars(int howMany)
    {

        
        
    }
}
