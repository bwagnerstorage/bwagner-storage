import greenfoot.*;

/**
 * Write a description of class Explosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explosion extends AnimatedActor
{
    public Explosion(String imageFile, int numframes, int frameWidth, int frameHeight)
    {
       super(imageFile, numframes, frameWidth, frameHeight);
    }
}
