import greenfoot.*;
import java.awt.*;


public class Platform extends Actor
{

}
