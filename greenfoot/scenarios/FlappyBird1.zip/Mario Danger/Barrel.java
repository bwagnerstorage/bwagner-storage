import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Barrel extends Actor
{
    private int dx;                // horizontal velocity
    private int rotationSpeed;     // rotational speed of barrel 
    private int platformLeftX;     // x coordinate of left edge of platform
    private int platformRightX;    // x coordinate of right edge of platform
    
    // constructor
    public Barrel(int dx, int platformLeftX, int platformRightX)
    {
        this.dx = dx;
        
        if(dx < 0)
           rotationSpeed = -3;
        else
           rotationSpeed = 3;
           
        this.platformLeftX = platformLeftX;
        this.platformRightX = platformRightX;
    }
    
    // act method
    public void act() 
    {

    }    
}
