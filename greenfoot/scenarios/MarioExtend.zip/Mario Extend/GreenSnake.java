import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GreenSnake here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GreenSnake extends AnimatedActor
{
    // constants
    final int GROUND_TOP = 338;
    
    // instance variables
    int counter = 0;
    
    public GreenSnake(String imageFile, int numframes, int frameWidth, int frameHeight)
    {
       super(imageFile, numframes, frameWidth, frameHeight);
       setAutoAdvance(true);
       setAdvanceSpeed(6);
       setLooping(true);
       setAutoAdvanceRange(0, 5);
       show();
    }
    
    public void act() 
    {
        super.act();
        
        if(counter % 2 == 0)
            move(-1);
        counter++;
        
        if(getX() < -getWidth())
           setLocation(600, getY());
    }    
}
