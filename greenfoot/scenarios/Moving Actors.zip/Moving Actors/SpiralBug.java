import greenfoot.*;      // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;   // Color

/**
 * Write a description of class SpiralBug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpiralBug extends Tracker
{
    
    
    public void act() 
    {
       
        
        
       
    }    
}
