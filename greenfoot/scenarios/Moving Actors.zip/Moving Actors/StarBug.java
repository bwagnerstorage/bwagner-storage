import greenfoot.*;      // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;   // Color

/**
 * Write a description of class StarBug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StarBug extends Tracker
{
    
    public void act() 
    {
        
        
        
        
    }    
}
