import greenfoot.*;

/**
 * Write a description of class BottomPlatform here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BottomPlatform extends Actor
{

}
