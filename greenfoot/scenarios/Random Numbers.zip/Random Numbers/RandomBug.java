import greenfoot.*;

/**
 * Write a description of class RandomBug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RandomBug extends Tracker
{
    public void act() 
    {
        
        startTrack(Color.BLUE, 3);
        move(Greenfoot.getRandomNumber(100));
        turn(Greenfoot.getRandomNumber(180));
        endTrack();
    }    
}
