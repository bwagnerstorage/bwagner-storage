package MyList;

public class MyList
{
    private ListNode front; // first node of this list (null if empty)
    private int listSize; // the number of elements in this list
    private int remIndex; // the index of the remembered node
    private ListNode remNode; // a reference to the node accessed by most recent call to get

    /** Constructs an empty MyList.
     */
    public MyList()
    {
        front = null;
        remIndex = -1;
        remNode = null;
        listSize = 0;
    }

    // part (a)
    /** Gets a value at a given index in this list.
     *  @param n the index at which to get a value
     *         Precondition: n < size()
     *  @return the object at the given index
     *  Postcondition: The remembered node and index refer to the node at index n
     */
    public Object get(int n)
    {


        return null;

    }

    // part (b)
    /** Adds a new node containing obj to the front of this list.
     *  @param obj the value to add to the list
     */
    public void addFirst(Object obj)
    {




    }

    /** @return the size of this list
     */
    public int size()
    {
        return listSize;
    }

    // There may be methods that are not shown.
    public void printList()
    {
    	ListNode temp = front;
    	int i=0;
    	while(temp != null)
    	{
    		System.out.print("(" + i + ", "+ temp.getValue() + ") ");
    		temp = temp.getNext();
    		i++;
    	}
    	System.out.println();
        System.out.println();
    }
}