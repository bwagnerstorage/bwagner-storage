package MyList;
        
public class Driver
{
    public static void main(String[] args)
    {
        MyList list = new MyList();

        list.addFirst("dog");
        list.addFirst("cat");
        list.addFirst("cow");
        list.addFirst("chicken");
        list.addFirst("horse");

        list.printList();


        System.out.println("list.get(2) = " + list.get(2));
        System.out.println("list.get(4) = " + list.get(4));
        System.out.println("list.get(0) = " + list.get(0));
        System.out.println("list.get(3) = " + list.get(3));
        System.out.println();

        list.addFirst("goat");
        list.addFirst("sheep");

        list.printList();

        System.out.println("list.get(6) = " + list.get(6));
        System.out.println("list.get(1) = " + list.get(1));
        System.out.println();

    }
}