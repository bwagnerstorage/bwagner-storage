package RobinHood;

import java.util.*;

public class RobinHood 
{
    // instance variables
    private int [][] town;
    private int numRows;     // number of rows
    private int numCols;     // number of columns
    
    // constructor
    public RobinHood()
    {
        // instantiate a 2D array (town)
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter number of rows -->");
        numRows = scan.nextInt();
        
        System.out.print("Enter number of columns -->");
        numCols = scan.nextInt();
        
        town = new int[numRows][numCols];
        
        // Unleash Robin Hood
        
        populateTown();
        System.out.println();
        System.out.println(" Original Town");
        System.out.println("===============");
        displayTown();
        int money = robTheRich();
        System.out.println("Money collected by Robin Hood = " + money);
        System.out.println();
        System.out.println(" Rob the Rich");
        System.out.println("===============");
        displayTown();
        giveToPoor(money);
        System.out.println();
        System.out.println(" Give to Poor");
        System.out.println("===============");
        displayTown();
    }
    
    /*
       Fills the town with random money values in the range of 1 to 20 inclusive.
    */
    public void populateTown()
    {
        for(int r = 0; r < numRows; r++)
        {
            for(int c = 0; c < numCols; c++)
            {
                town[r][c] = (int)(Math.random() * 20 + 1);  // 1..20
            }
        }
    }
    
    // Part A
    /* 
       Displays the town in row-major order. If the money value in an array
       cell is less than 10 the method adds a space in front of the single
       digit when it is displayed.
    */
    public void displayTown()
    {

    }
    
    // Part B
    /* 
       Traverses the town looking for the rich. (A family is rich if their 
       value is greater than 10.) If a rich family is found all their money
       is confiscated. The total amount of money collected from  
       all the rich is returned.
       @return the money collected
    */
    public int robTheRich()
    {
        return 0;
    }
    
    // Part C
    /*
       Returns a count of the number of families in the town that are poor.
    */
    public int countThePoor()
    {
        return 0;
    }
    
    // Part D
    /*
       Divides the moneyCollected into equal portions and 
       distributes it to the poor.
       @param moneyCollected the money confiscated from the rich
    */
    public void giveToPoor(int moneyCollected)
    {

    }
    
    public static void main(String[] args)
    {
        RobinHood app = new RobinHood();
    }
    
}
