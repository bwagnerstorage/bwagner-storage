package WaitingList;

public class WaitingList
{
	private int numNodes;
	private ListNode front;

	public WaitingList()
	{
		numNodes = 0;
		front = null;
	}

	// returns the number of nodes in this list
	public int size()
	{
	   return numNodes;
	}

    // part (a)
	// returns a reference to the node at index k,
	// where the indexes are numbered 0 through size()-1
	// precondition: 0 <= k < size()
	private ListNode getKthNode(int k)
	{

            return null;
	}

    // part (b)
	// removes the last num nodes from other and attaches them
	// in the same order to the end of this WaitingList;
	// updates the number of nodes in each list to reflect the move
	// precondition:   size() > 0;
	//	0 < num <= other.size()
	public void transferNodesFromEnd(WaitingList other, int num)
	{


	}

	public void add(String data)
	{
	   ListNode current = front;
	   ListNode node = new ListNode(data, null);

	   if(front == null)
	   {
	   	 front = node;
	   }
	   else
	   {
		   for(int i=0; i < size() - 1 ; i++)
		   {
		   	  current = current.getNext();
		   }
	       current.setNext(node);
	   }
	   numNodes++;

	}

	public void printList()
	{
		ListNode current = front;
		while(current != null)
		{
			System.out.print(current.getValue() + " ");
			current = current.getNext();
		}
		System.out.println(); System.out.println();
	}

    public static void main(String[] args)
    {
    	WaitingList list1 = new WaitingList();
    	list1.add("A");
    	list1.add("B");
    	list1.add("C");

    	System.out.print("List 1 = ");
    	list1.printList();

    	WaitingList list2 = new WaitingList();
    	list2.add("E");
    	list2.add("F");

    	System.out.print("List 2 = ");
    	list2.printList();

    	System.out.println("=====================");
    	System.out.println(" Test 1 - getKthNode");
    	System.out.println("=====================\n");
    	ListNode node1 = list1.getKthNode(0);
    	System.out.println(node1.getValue());
    	ListNode node2 = list1.getKthNode(2);
    	System.out.println(node2.getValue());
    	System.out.println();

    	System.out.println("===============================");
    	System.out.println(" Test 2 - transferNodesFromEnd");
    	System.out.println("===============================");
    	list2.transferNodesFromEnd(list1, 1);

    	System.out.print("List 1 = ");
    	list1.printList();
    	System.out.print("List 2 = ");
    	list2.printList();

    	System.out.println("List 1 size = " + list1.size());
    	System.out.println("List 2 size = " + list2.size());
    	System.out.println();

    	list1 = new WaitingList();
    	list1.add("A");
    	list1.add("B");
    	list1.add("C");

    	list2 = new WaitingList();
    	list2.add("E");
    	list2.add("F");

    	System.out.println("===============================");
    	System.out.println(" Test 3 - transferNodesFromEnd");
    	System.out.println("===============================");
    	list2.transferNodesFromEnd(list1, 2);

    	System.out.print("List 1 = ");
    	list1.printList();
    	System.out.print("List 2 = ");
    	list2.printList();

    	System.out.println("List 1 size = " + list1.size());
    	System.out.println("List 2 size = " + list2.size());
    	System.out.println();

    	list1 = new WaitingList();
    	list1.add("A");
    	list1.add("B");
    	list1.add("C");

    	list2 = new WaitingList();
    	list2.add("E");
    	list2.add("F");

    	System.out.println("===============================");
    	System.out.println(" Test 4 - transferNodesFromEnd");
    	System.out.println("===============================");
    	list2.transferNodesFromEnd(list1, 3);

    	System.out.print("List 1 = ");
    	list1.printList();
    	System.out.print("List 2 = ");
    	list2.printList();

    	System.out.println("List 1 size = " + list1.size());
    	System.out.println("List 2 size = " + list2.size());
    	System.out.println();


    }
}
