package Problem2;

import java.util.*;

public class GarageSale
{
	//Instance Variables

	
	// Constructor
	public GarageSale()
	{

	}
	
	// Mutator Method
	public void addItem(GarageSaleItem item)
	{

	}
	
	// Accessor Methods	
	public GarageSaleItem getItem(int index)
	{
       
	}
	
	public int getTotalItemsCollected()
	{
	   
	}
	
	public int getTotalItemsSold()
	{

	}
	
	public double getTotalSales()
	{

	}
}