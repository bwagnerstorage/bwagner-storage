package javafxexercise4;

import javafx.beans.property.SimpleStringProperty;

public class Candidate
{
    private SimpleStringProperty  name;
    private SimpleStringProperty votes;
    
    public Candidate(String n, int v)
    {
        name = new SimpleStringProperty(n);
        votes = new SimpleStringProperty(new Integer(v).toString());
    }
 
    public String getName() {
        return name.get();
    }

    public void setName(String n) {
        name.set(n);
    }

    public String getVotes() {
        return votes.get();
    }

    public void setVotes(int v) {
        votes.set(new Integer(v).toString());
    }
}