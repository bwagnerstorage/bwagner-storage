package javafxexercise4;

public class FXMLDocumentController
{
    
   public void initialize()
   {
       
   }
}