package javafxexercise3;

import java.io.*;
import java.util.*;

public class MyModel 
{
    // instance variables
    private List <String> myList;
    
    public MyModel()
    {
        myList = new ArrayList<>();
        load();
    }
    
    public void load()
    {
        try 
        {
            Scanner input = new Scanner(new File("data.txt"));
            while(input.hasNextLine())
            {
                myList.add(input.nextLine());
            }
            input.close();
        }
        catch(IOException e)
        {}
    }
    
    public void save()
    {
        try 
        {
            PrintWriter output = new PrintWriter(new File("data.txt"));
            for(String str : myList)
            {
                output.println(str);
            }
            output.close();
        }
        catch(IOException e)
        {}
    }
    
    // methods
    public void add(String str)
    {
        myList.add(str);
    }
    
    public void remove(int index)
    {
        myList.remove(index);
    }
    
    public String get(int index)
    {
        return myList.get(index);
    }
    
    public List<String> getList()
    {
        return myList;
    }
}
