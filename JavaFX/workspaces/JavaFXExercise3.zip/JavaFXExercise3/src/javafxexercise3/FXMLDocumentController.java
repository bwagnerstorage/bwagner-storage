
package javafxexercise3;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class FXMLDocumentController  {
    
    private MyModel model = new MyModel();
    private ObservableList<String> observableList; 
    
    @FXML
    private TextField myTextField;
    
    @FXML
    private ListView myListView;
    
    // event handler
    
   @FXML
    private void handleButtonAction(ActionEvent event) {
        String text = myTextField.getText();
        myTextField.clear();
        observableList.add(text);
    }

    public void shutdown() {
        model.save();
    }
   
    // This method is automatically called by the loader after all the annotated variables
    // have been injected with their corresponding FXML generated components.
    public void initialize() {
        observableList = FXCollections.observableList(model.getList());
        myListView.setItems(observableList);
    }    
    
}
